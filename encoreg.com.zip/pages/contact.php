<?php
include('../model/constant.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Your Trusted Global Partner in Electronics & Industrial Trade</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= HTTP_SERVER ?>lib/animate/animate.min.css" rel="stylesheet">
    <!-- Change paths to work from both locations -->
    <link href="<?= HTTP_SERVER ?>lib/animate/animate.min.css" rel="stylesheet">
    <link href="<?= HTTP_SERVER ?>lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <!-- And so on -->
    <!-- Customized Bootstrap Stylesheet -->
    <link href="../..css/bootstrap.min.css" rel="stylesheet">
    <script type="text/javascript" src="https://cdn.emailjs.com/dist/email.min.js"></script>
    <!-- Template Stylesheet -->
    <link href="../css/style.css" rel="stylesheet">
    <style>
        /* Custom styles for the address section */
        .d-flex.align-items-start {
            margin-bottom: 15px;
        }

        .bi-geo-alt-fill {
            font-size: 1.5rem;
            /* Adjust the icon size */
            margin-right: 15px;
            /* Add space between the icon and the text */
        }
        
    </style>
</head>

<body>


    <?php include '../include/layout/header.php' ?>
    <?php include '../spinner.php'; ?>
    <?php include '../include/layout/navbar.php' ?>
    <div class="container-fluid page-header page-header-contact  py-5 mb-5">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Contact Us</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a class="text-white" href="<?= HTTP_SERVER ?>index">Home</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Contact Us</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Contact Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-4">
                <!-- Left Column (Contact Info) -->
                <div class="col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="text-primary">Get In Touch</h6>
                    <h1 class="mb-4">Contact For Any Query</h1>

                    <!-- Row for contact info -->
                    <div class="row mb-4">

                        <div class="col-6 d-flex align-items-start">
                            <i class="bi bi-envelope-fill text-primary fs-4 me-3"></i>
                            <div>
                                <h6 class="mb-0">Email</h6>
                                <small>contact@encoreg.com</small>
                            </div>
                        </div>
                        <!-- Address -->

                        <!-- Email -->

                        <!-- Phone -->
                        <div class="col-6 d-flex align-items-start">
                            <i class="bi bi-telephone-fill text-primary fs-4 me-3"></i>
                            <div>
                                <h6 class="mb-0">Phone</h6>
                                <small>+86 1314 580 2785</small>
                            </div>
                        </div>

                        <div class="col-6 d-flex align-items-start">
                            <i class="bi bi-geo-alt-fill text-primary fs-4 me-3"></i>
                            <div>
                                <h6 class="mb-0">Shenzhen </h6>
                                <small>619, 6F, Town 2, Shenhua Technology Park 2nd Meixiu Road, Futian District, Shenzhen</small>
                            </div>
                        </div>
                        <div class="col-6 d-flex align-items-start">
                            <i class="bi bi-geo-alt-fill text-primary fs-4 me-3"></i>
                            <div>
                                <h6 class="mb-0">Hong Kong</h6>
                                <small>721, 7/F, Liven House, No.61‐63, King Yip Street, Kwun Tong, KL , Hong Kong</small>
                            </div>
                        </div>
                    </div>

                    <!-- Google Map -->
                    <iframe class="position-relative w-100"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.782853364635!2d114.04217381498185!3d22.543520285020484!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3403f5f8f019c7bf%3A0x2a5e69d8bfcf4c97!2s619%2C%206F%2C%20Town%202%2C%20Shenhua%20Technology%20Park%202nd%20Meixiu%20Road%2C%20Futian%20District%2C%20Shenzhen!5e0!3m2!1sen!2sbd!4v1603794290143!5m2!1sen!2sbd"
                        frameborder="0" style="height: 385px; border:0;" allowfullscreen="" aria-hidden="false"
                        tabindex="0"></iframe>
                </div>


                <!-- Include EmailJS SDK -->

                <script type="text/javascript">
                    (function() {
                        emailjs.init("GsnLqokYLOYCpA0yd"); // Replace with your actual EmailJS public key
                    })();
                </script>

                <div class="col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="bg-light p-5 h-100 d-flex align-items-center">
                        <form id="contactForm">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Name">
                                        <label for="name">Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="company" name="company" placeholder="Company Name">
                                        <label for="company">Company Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Email ID">
                                        <label for="email">Email ID</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="tel" class="form-control" id="phone" name="phone" placeholder="Phone Number">
                                        <label for="phone">Phone Number</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="enquiry" name="enquiry" placeholder="Enquiry About">
                                        <label for="enquiry">Enquiry About</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <textarea class="form-control" placeholder="Leave a message here" id="message" name="message" style="height: 150px"></textarea>
                                        <label for="message">Message</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary w-100 py-3" type="submit">Send Message</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- JavaScript to handle form submission -->
                <script>
                    document.getElementById('contactForm').addEventListener('submit', function(event) {
                        event.preventDefault();

                        // Show the popup right away
                        showPopup();

                        // Then send the form via EmailJS in the background
                        emailjs.sendForm('service_o1agv1l', 'template_vv7hdws', this)
                            .then(function(response) {
                                console.log('SUCCESS!', response.status, response.text);
                            }, function(error) {
                                alert("Failed to send message. Please try again.");
                                console.log('FAILED...', error);
                            });

                        this.reset(); // Optionally reset the form after submission
                    });

                    function showPopup() {
                        const popup = document.getElementById('popupMessage');
                        popup.style.display = 'block';
                        popup.style.opacity = '1';

                        setTimeout(() => {
                            popup.style.opacity = '0';
                            setTimeout(() => popup.style.display = 'none', 500);
                        }, 2000);
                    }
                </script>

            </div>
        </div>
    </div>

    <div id="popupMessage" style="
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #1e60aa !important;
    color: white;
    padding: 15px 30px;
    border-radius: 10px;
    font-size: 15px;
    font-weight: 500;
    z-index: 9999;
    backdrop-filter: blur(6px);
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    transition: opacity 0.5s ease;
">
        We'll reach you right back!
    </div>


    <!-- Contact End -->

    <!-- Footer End -->

    <?php include '../include/layout/footer.php' ?>
    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-0 back-to-top"><i class="bi bi-arrow-up"></i></a>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= HTTP_SERVER ?>lib/wow/wow.min.js"></script>
    <script src="<?= HTTP_SERVER ?>lib/easing/easing.min.js"></script>
    <script src="<?= HTTP_SERVER ?>lib/waypoints/waypoints.min.js"></script>
    <script src="<?= HTTP_SERVER ?>lib/counterup/counterup.min.js"></script>
    <script src="<?= HTTP_SERVER ?>lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="<?= HTTP_SERVER ?>js/main.js"></script>


</body>

</html>